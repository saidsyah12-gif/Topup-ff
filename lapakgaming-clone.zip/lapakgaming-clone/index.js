<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LapakGaming Clone</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>🎮 LGS - LapakGaming Store 🎮</h1>
    <p>Top Up Game Murah, Cepat, & Aman</p>
  </header>

  <main>
    <section class="game-section">
      <h2>Pilih Game</h2>
      <select id="gameSelect" onchange="updateNominalOptions()">
        <option value="">-- Pilih Game --</option>
        <option value="freefire">Free Fire</option>
        <option value="mlbb">Mobile Legends</option>
        <option value="pubg">PUBG Mobile</option>
      </select>
    </section>

    <section class="form-section">
      <h2>Form Top Up</h2>
      <input type="text" id="playerId" placeholder="Masukkan ID Game" required />
      
      <select id="nominal" onchange="hitungTotal()">
        <option value="">-- Pilih Nominal Diamond/UC --</option>
      </select>

      <select id="metodeBayar" required>
        <option value="">-- Pilih Metode Pembayaran --</option>
        <option value="dana">DANA</option>
        <option value="ovo">OVO</option>
        <option value="qris">QRIS</option>
        <option value="gopay">GoPay</option>
      </select>

      <p id="totalHarga">Total: Rp0</p>

      <button onclick="submitTopup()">Checkout</button>
      <p id="statusPesan"></p>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 LapakGamingStore. All rights reserved.</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
