const hargaPerGame = {
  freefire: {100: 1000, 200: 2000, 500: 5000},
  mlbb:     {86: 1500, 172: 3000, 257: 4500},
  pubg:     {60: 1000, 180: 3000, 600: 9000}
};

function updateNominalOptions() {
  const game = document.getElementById("gameSelect").value;
  const nominalSelect = document.getElementById("nominal");

  nominalSelect.innerHTML = "<option value=''>-- Pilih Nominal Diamond/UC --</option>";

  if (hargaPerGame[game]) {
    for (let jumlah in hargaPerGame[game]) {
      const option = document.createElement("option");
      option.value = jumlah;
      option.text = `${jumlah} Diamond/UC`;
      nominalSelect.add(option);
    }
  }

  document.getElementById("totalHarga").innerText = "Total: Rp0";
}

function hitungTotal() {
  const game = document.getElementById("gameSelect").value;
  const nominal = document.getElementById("nominal").value;
  const total = hargaPerGame[game]?.[nominal] || 0;

  document.getElementById("totalHarga").innerText = "Total: Rp" + total.toLocaleString();
}

function submitTopup() {
  const id = document.getElementById("playerId").value;
  const game = document.getElementById("gameSelect").value;
  const jumlah = document.getElementById("nominal").value;
  const metode = document.getElementById("metodeBayar").value;

  if (!id || !game || !jumlah || !metode) {
    alert("Harap lengkapi semua data!");
    return;
  }

  const total = hargaPerGame[game][jumlah];
  document.getElementById("statusPesan").innerText = 
    `✅ Top up ${jumlah} Diamond/UC untuk ID ${id} (${game.toUpperCase()}) berhasil diproses. Bayar Rp${total.toLocaleString()} via ${metode.toUpperCase()}`;
}
